/* 5-2.c 
#include<stdio.h>
int main(void)
{
	int i=0, j=0, k=0;

	printf("i = %d, j = %d, k = %d\n", i, j, k);

	i = 1;
	j = 5; 
	k = 7;

	printf("i = %d, j = %d, k = %d\n", i, j, k);

	return 0;
}*/
