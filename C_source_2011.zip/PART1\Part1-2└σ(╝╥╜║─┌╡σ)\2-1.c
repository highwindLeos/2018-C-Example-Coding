/* 2-1.c
#include<stdio.h>
int main(void)
{
	printf("Hello C world");
	
	return 0;
} */