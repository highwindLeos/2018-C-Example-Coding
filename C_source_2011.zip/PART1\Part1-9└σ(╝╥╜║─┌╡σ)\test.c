/* test.c 
int num1=5;
int num2=10;
int num3=20;

void add(void)
{
	num3=num1+num2;
}*/