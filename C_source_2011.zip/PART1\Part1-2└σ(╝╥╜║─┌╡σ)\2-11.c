/* 2-11.c 
#include <stdio.h>
int main(void)
{
	int age;

	printf("What is your age?: ");
	scanf("%d", &age);
	printf("Wow! Really? Are you %d years old?\n", age);

	return 0;
}*/