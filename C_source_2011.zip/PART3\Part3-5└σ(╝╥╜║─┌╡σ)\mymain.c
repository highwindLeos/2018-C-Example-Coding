/*  mymain.c  
#include <stdio.h>
int main(void)
#include "myheader1.h"
#include "myheader2.h"
*/