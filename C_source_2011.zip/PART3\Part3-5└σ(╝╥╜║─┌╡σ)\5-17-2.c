/* 5-17-2.c 
#include<stdio.h>

extern int a, b; 

int main(void)
{
	int result = 0;
	result = a + b;
	printf("���� ���: %d \n", result);   

    return 0;
}*/
