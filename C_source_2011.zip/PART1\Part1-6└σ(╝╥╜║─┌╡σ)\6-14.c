/* 6-14.c 
#include <stdio.h>
typedef int money;
int main(void)
{
		money num1=3000;
		money num2=10000;
		money num3=2000;
		money num4=0;
			
		num4=num1+num2+num3+num4;
		printf("total money : %d won \n", num4);
			
		return 0;
}
*/
