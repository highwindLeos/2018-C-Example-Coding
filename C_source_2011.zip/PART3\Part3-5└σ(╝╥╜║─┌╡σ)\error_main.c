/* error_main.c  
#include <stdio.h>
int main(void)
#include "header1.h"
#include "header2.h"
*/