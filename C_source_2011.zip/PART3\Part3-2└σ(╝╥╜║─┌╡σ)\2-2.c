/* 2-2.c 
#include<stdio.h>
int main(void)
{
	char array1[20];
	char array2[20];

	gets(array1);                // what is your name? �Է�
	a=puts(array1);		         // what is your name? ���

	scanf ("%s",array2);         // what is your name? �Է�
	printf("%s\n", array2);	     // what ���

	return 0;
} */