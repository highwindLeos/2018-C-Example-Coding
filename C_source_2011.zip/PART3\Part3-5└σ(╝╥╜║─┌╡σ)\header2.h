/*  header2.h  
#include "header1.h"		
	
		return 0;
}
*/