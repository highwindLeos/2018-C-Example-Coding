/* 4-8.c 
#include <stdio.h>

#define PI 3.14
#define NUM 100
#define BUFFER_SIZE 200

int main()
{
   printf("%lf \n",PI);
   printf("%d \n",NUM);
   printf("%d \n",BUFFER_SIZE);

   return 0;
}*/ 