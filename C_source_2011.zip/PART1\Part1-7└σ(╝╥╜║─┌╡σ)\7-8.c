/* 7-8.c 
#include <stdio.h>
int main(void)
{
		int num=0, i, result=0;
		
		printf("���ڸ� �Է��ϼ��� : ");
		scanf("%d", &num);
		
		for(i=1; i<10; i=i+2)
		{
			result=num*i;
			printf("%d * %d = %d�Դϴ�. \n", num, i, result);
		}
		
		return 0;
}*/
