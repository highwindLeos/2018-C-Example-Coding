/* 6-12.c 
#include <stdio.h>
int main(void)
{
		char num1=130;
		int num2=3.14;
		double num3=3;
		
		printf("%d, %d, %lf \n", num1, num2, num3);
	
		return 0;
}
*/