/* 7-16.c 
#include <stdio.h>
int main( )
{
		int num=10;
		
		do
		{
			printf("%d", num);
			num++;
		}while(num<10);
		
		printf("\n **while ���� �����մϴ�.** \n");
		
		return 0;
}*/
