/* 5-12.c 
#include<stdio.h>
int main(void)
{
	int num1=2, num2=3;
	int result1;

	result1 = (num1>num2) ? num1 : num2;
	printf("result1�� ����� �� %d \n",result1);

	return 0;
}*/
