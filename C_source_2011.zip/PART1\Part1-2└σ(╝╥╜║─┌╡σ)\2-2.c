/* 2-2.c
#include <stdio.h>
int main(void)	
{
	printf("Hello C world \n");

	return 0;
}
 */