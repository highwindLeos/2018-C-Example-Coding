/* 5-18-2.c
#include<stdio.h>

extern int num1, num2;
extern void add(int num1, int num2);

int main(void)
{
	add(num1,num2);
	return 0;
} */